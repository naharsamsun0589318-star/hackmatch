// LocalStorage Initialization
if (!localStorage.getItem('users')) localStorage.setItem('users', JSON.stringify([]));
if (!localStorage.getItem('teams')) {
  localStorage.setItem('teams', JSON.stringify([
    { name: "Code Hackers", members: ["Rahul Sen", "Priya Das", "Amit Paul"] },
    { name: "Tech Ninjas", members: ["Sayan Roy", "Riya Basu"] }
  ]));
}

function showNotification(msg) {
  const notif = document.getElementById('notification');
  if (notif) {
    notif.innerText = msg;
    notif.style.display = 'block';
    setTimeout(() => { notif.style.display = 'none'; }, 3000);
  }
}

// 1. Registration Logic
const regForm = document.getElementById('regForm');
if (regForm) {
  regForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('regName').value;
    const email = document.getElementById('regEmail').value;
    const regNo = 'REG' + Math.floor(1000 + Math.random() * 9000);

    const users = JSON.parse(localStorage.getItem('users'));
    users.push({ name, email, regNo, skills: '', status: '', eligible: false });
    localStorage.setItem('users', JSON.stringify(users));

    alert(`Registration Successful!\nYour Registration Number is: ${regNo}`);
    window.location.href = 'login.html';
  });
}

// 2. Login Logic
const loginForm = document.getElementById('loginForm');
if (loginForm) {
  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const regNo = document.getElementById('loginRegNo').value.trim();
    const users = JSON.parse(localStorage.getItem('users'));
    const user = users.find(u => u.regNo === regNo);

    if (user) {
      localStorage.setItem('currentUser', JSON.stringify(user));
      alert("Login Successful!");
      window.location.href = 'profile.html';
    } else {
      document.getElementById('loginError').innerText = "Invalid Registration Number!";
    }
  });
}

// 3. Profile Setup & Edit Logic
const profileForm = document.getElementById('profileForm');
if (profileForm) {
  const currentUser = JSON.parse(localStorage.getItem('currentUser'));
  const skillsInput = document.getElementById('profileSkills');
  const statusInput = document.getElementById('profileStatus');
  const saveBtn = document.getElementById('saveProfileBtn');
  const editBtn = document.getElementById('editProfileBtn');
  const proceedBtn = document.getElementById('proceedBtn');

  if (currentUser && currentUser.skills) {
    skillsInput.value = currentUser.skills;
    statusInput.value = currentUser.status;
    skillsInput.disabled = true;
    statusInput.disabled = true;
    saveBtn.style.display = 'none';
    editBtn.style.display = 'inline-block';
    proceedBtn.style.display = 'inline-block';
  }

  profileForm.addEventListener('submit', (e) => {
    e.preventDefault();
    currentUser.skills = skillsInput.value;
    currentUser.status = statusInput.value;
    
    // Eligibility criteria check (Needs at least 3 chars in skills)
    currentUser.eligible = currentUser.skills.trim().length >= 3;

    updateUser(currentUser);
    showNotification("Profile status updated successfully!");

    skillsInput.disabled = true;
    statusInput.disabled = true;
    saveBtn.style.display = 'none';
    editBtn.style.display = 'inline-block';
    proceedBtn.style.display = 'inline-block';
  });

  if (editBtn) {
    editBtn.addEventListener('click', () => {
      skillsInput.disabled = false;
      statusInput.disabled = false;
      saveBtn.style.display = 'inline-block';
      editBtn.style.display = 'none';
    });
  }
}

// 4. Dashboard Logic
const teamsList = document.getElementById('teamsList');
if (teamsList) {
  const currentUser = JSON.parse(localStorage.getItem('currentUser'));
  if (document.getElementById('userName')) {
    document.getElementById('userName').innerText = `${currentUser.name} (${currentUser.regNo})`;
  }

  // Render Participating Teams
  const teams = JSON.parse(localStorage.getItem('teams'));
  teamsList.innerHTML = '';
  teams.forEach((t, index) => {
    const div = document.createElement('div');
    div.className = 'team-item';
    div.innerHTML = `<strong>👥 ${t.name}</strong> (${t.members.length} members)
      <div class="team-members" id="team-${index}">
        <ul>${t.members.map(m => `<li>${m}</li>`).join('')}</ul>
      </div>`;
    
    div.addEventListener('click', () => {
      const memBox = document.getElementById(`team-${index}`);
      memBox.style.display = memBox.style.display === 'block' ? 'none' : 'block';
    });

    teamsList.appendChild(div);
  });

  // Acceptance / Rejection Status Decision
  const statusContainer = document.getElementById('statusContainer');
  if (statusContainer) {
    if (currentUser.eligible) {
      statusContainer.className = 'status-box status-accepted';
      statusContainer.innerHTML = '<h4>Status: ACCEPTED ✅</h4><p>Your profile is eligible for Hackathon participation!</p>';
    } else {
      statusContainer.className = 'status-box status-rejected';
      statusContainer.innerHTML = '<h4>Status: REJECTED ❌</h4><p><strong>Reason:</strong> Please update your skills properly in your Profile page to get accepted.</p>';
    }
  }
}

// 5. Create Team Logic
const createTeamForm = document.getElementById('createTeamForm');
if (createTeamForm) {
  createTeamForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const teamName = document.getElementById('teamName').value;
    const inputs = document.querySelectorAll('.member-input');
    const members = [];

    inputs.forEach(inp => {
      if (inp.value.trim() !== '') members.push(inp.value.trim());
    });

    if (members.length === 0) {
      alert("Please enter at least 1 member name!");
      return;
    }

    const teams = JSON.parse(localStorage.getItem('teams'));
    teams.push({ name: teamName, members });
    localStorage.setItem('teams', JSON.stringify(teams));

    alert("Confirmation: Team Created Successfully!");
    window.location.href = 'dashboard.html';
  });
}

function updateUser(updatedUser) {
  localStorage.setItem('currentUser', JSON.stringify(updatedUser));
  const users = JSON.parse(localStorage.getItem('users'));
  const idx = users.findIndex(u => u.regNo === updatedUser.regNo);
  if (idx !== -1) {
    users[idx] = updatedUser;
    localStorage.setItem('users', JSON.stringify(users));
  }
}